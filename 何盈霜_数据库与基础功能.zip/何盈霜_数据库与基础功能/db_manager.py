# 数据库管理器 - 支持MySQL/SQLite切换
import os
import sqlite3

# 数据库配置
DB_CONFIG = {
    'type': os.environ.get('DB_TYPE', 'sqlite'),  # sqlite 或 mysql
    'host': os.environ.get('DB_HOST', 'localhost'),
    'port': int(os.environ.get('DB_PORT', 3306)),
    'database': os.environ.get('DB_NAME', 'cnagentos'),
    'user': os.environ.get('DB_USER', 'root'),
    'password': os.environ.get('DB_PASSWORD', ''),
}

# 获得项目根路径的方法
def _project_root():
    return os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))

# SQLite 数据库路径
DB_PATH = os.path.join(_project_root(), "database", "app.db")

class DatabaseManager:
    """数据库管理器"""
    
    _instance = None
    _db_type = 'sqlite'
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(DatabaseManager, cls).__new__(cls)
        return cls._instance
    
    @classmethod
    def get_db_type(cls):
        return cls._db_type
    
    @classmethod
    def set_db_type(cls, db_type):
        """切换数据库类型"""
        if db_type not in ['sqlite', 'mysql']:
            raise ValueError("不支持的数据库类型，仅支持 sqlite 或 mysql")
        cls._db_type = db_type
        DB_CONFIG['type'] = db_type
    
    @classmethod
    def get_connection(cls):
        """获取数据库连接"""
        if cls._db_type == 'mysql':
            return cls._get_mysql_connection()
        else:
            return cls._get_sqlite_connection()
    
    @classmethod
    def _get_sqlite_connection(cls):
        """获取SQLite连接"""
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        return conn
    
    @classmethod
    def _get_mysql_connection(cls):
        """获取MySQL连接"""
        try:
            import pymysql
            conn = pymysql.connect(
                host=DB_CONFIG['host'],
                port=DB_CONFIG['port'],
                database=DB_CONFIG['database'],
                user=DB_CONFIG['user'],
                password=DB_CONFIG['password'],
                charset='utf8mb4',
                cursorclass=pymysql.cursors.DictCursor
            )
            return conn
        except ImportError:
            print("警告: pymysql 未安装，回退到 SQLite")
            return cls._get_sqlite_connection()
        except Exception as e:
            print(f"MySQL连接失败: {e}，回退到 SQLite")
            return cls._get_sqlite_connection()
    
    @classmethod
    def test_mysql_connection(cls, host, port, database, user, password):
        """测试MySQL连接"""
        try:
            import pymysql
            conn = pymysql.connect(
                host=host,
                port=int(port),
                database=database,
                user=user,
                password=password,
                charset='utf8mb4',
                cursorclass=pymysql.cursors.DictCursor,
                connect_timeout=5
            )
            conn.close()
            return True, "连接成功"
        except ImportError:
            return False, "pymysql 未安装，请执行: pip install pymysql"
        except Exception as e:
            return False, str(e)
    
    @classmethod
    def init_mysql_tables(cls):
        """初始化MySQL表结构"""
        try:
            import pymysql
            conn = pymysql.connect(
                host=DB_CONFIG['host'],
                port=DB_CONFIG['port'],
                database=DB_CONFIG['database'],
                user=DB_CONFIG['user'],
                password=DB_CONFIG['password'],
                charset='utf8mb4',
                cursorclass=pymysql.cursors.DictCursor
            )
            
            cursor = conn.cursor()
            
            # 创建用户表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    username VARCHAR(50) NOT NULL UNIQUE,
                    password_hash VARCHAR(255) NOT NULL,
                    salt VARCHAR(255) NOT NULL,
                    nickname VARCHAR(50),
                    avatar VARCHAR(255),
                    status TINYINT DEFAULT 1,
                    create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            
            # 创建角色表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS roles (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(50) NOT NULL UNIQUE,
                    code VARCHAR(50) NOT NULL UNIQUE,
                    is_system TINYINT DEFAULT 0,
                    create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            
            # 创建菜单表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS menus (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    parent_id INT DEFAULT 0,
                    name VARCHAR(50) NOT NULL,
                    url VARCHAR(255),
                    icon VARCHAR(50),
                    order_num INT DEFAULT 0,
                    create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            
            # 创建角色菜单映射表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS role_menus (
                    role_id INT,
                    menu_id INT,
                    PRIMARY KEY (role_id, menu_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            
            # 创建用户角色映射表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS user_roles (
                    user_id INT,
                    role_id INT,
                    PRIMARY KEY (user_id, role_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            
            # 创建模型引擎表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS ai_models (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    model_name VARCHAR(100) NOT NULL,
                    api_key VARCHAR(255) NOT NULL,
                    base_url VARCHAR(255) NOT NULL,
                    is_default TINYINT DEFAULT 0,
                    total_tokens INT DEFAULT 0,
                    create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            
            # 创建瞭望数据源表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS spy_sources (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    entry_url TEXT NOT NULL,
                    request_headers TEXT NOT NULL,
                    is_active TINYINT DEFAULT 1,
                    create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            
            # 创建数据仓库表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS spy_data (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    source_id INT NOT NULL,
                    keyword VARCHAR(255) NOT NULL,
                    title TEXT NOT NULL,
                    url TEXT NOT NULL,
                    summary TEXT,
                    create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    update_at TIMESTAMP NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            
            # 创建好友关系表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS friendships (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT NOT NULL,
                    friend_id INT NOT NULL,
                    status TINYINT DEFAULT 1,
                    create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE KEY unique_friendship (user_id, friend_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            
            # 创建群聊表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS chat_groups (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    avatar VARCHAR(255),
                    owner_id INT NOT NULL,
                    description TEXT,
                    status TINYINT DEFAULT 1,
                    is_system TINYINT DEFAULT 0,
                    announcement TEXT,
                    create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            
            # 创建群成员表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS group_members (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    group_id INT NOT NULL,
                    user_id INT NOT NULL,
                    role TINYINT DEFAULT 0,
                    nickname_in_group VARCHAR(50),
                    join_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE KEY unique_member (group_id, user_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            
            # 创建消息表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS messages (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    sender_id INT NOT NULL,
                    receiver_id INT,
                    group_id INT,
                    msg_type TINYINT DEFAULT 1,
                    content TEXT NOT NULL,
                    file_url VARCHAR(255),
                    file_name VARCHAR(255),
                    file_size INT,
                    is_read TINYINT DEFAULT 0,
                    is_deleted TINYINT DEFAULT 0,
                    create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            
            # 创建文件管理表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS files (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    file_hash VARCHAR(64) NOT NULL UNIQUE,
                    file_name VARCHAR(255) NOT NULL,
                    file_path TEXT NOT NULL,
                    file_size INT NOT NULL,
                    mime_type VARCHAR(100),
                    uploader_id INT,
                    ref_count INT DEFAULT 1,
                    create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            
            # 创建数字员工表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS digital_employees (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL UNIQUE,
                    display_name VARCHAR(100) NOT NULL,
                    avatar VARCHAR(255),
                    description TEXT,
                    employee_type VARCHAR(50) NOT NULL,
                    prompt_template TEXT,
                    model_id INT,
                    tools JSON,
                    is_active TINYINT DEFAULT 1,
                    create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            
            # 创建聊天服务器表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS chat_servers (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    host VARCHAR(255) NOT NULL,
                    port INT NOT NULL,
                    ws_port INT,
                    status TINYINT DEFAULT 1,
                    priority INT DEFAULT 0,
                    is_default TINYINT DEFAULT 0,
                    create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            
            # 创建工具管理表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS tools (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL UNIQUE,
                    display_name VARCHAR(100) NOT NULL,
                    description TEXT,
                    tool_type VARCHAR(50) NOT NULL,
                    config JSON,
                    is_active TINYINT DEFAULT 1,
                    create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            
            # 创建数字员工工具绑定表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS employee_tools (
                    employee_id INT,
                    tool_id INT,
                    config JSON,
                    PRIMARY KEY (employee_id, tool_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            
            # 创建舆情数据表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS sentiment_data (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    source_type VARCHAR(50) NOT NULL,
                    source_id INT NOT NULL,
                    content TEXT NOT NULL,
                    sentiment_score FLOAT,
                    keywords JSON,
                    analysis_result TEXT,
                    create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            
            # 创建索引
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_friendships_user ON friendships(user_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_group_members_group ON group_members(group_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_messages_sender ON messages(sender_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_messages_receiver ON messages(receiver_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_messages_group ON messages(group_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_spy_data_source_url ON spy_data(source_id, url)")
            
            conn.commit()
            cursor.close()
            conn.close()
            
            return True, "MySQL表初始化成功"
            
        except Exception as e:
            return False, f"MySQL表初始化失败: {str(e)}"
    
    @classmethod
    def migrate_sqlite_to_mysql(cls):
        """从SQLite迁移数据到MySQL"""
        try:
            # 获取SQLite数据
            sqlite_conn = cls._get_sqlite_connection()
            sqlite_cursor = sqlite_conn.cursor()
            
            # 获取所有表
            sqlite_cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [row[0] for row in sqlite_cursor.fetchall()]
            
            # 获取MySQL连接
            mysql_conn = cls._get_mysql_connection()
            mysql_cursor = mysql_conn.cursor()
            
            migrated_count = 0
            
            for table in tables:
                if table.startswith('sqlite_'):
                    continue
                    
                # 获取SQLite数据
                sqlite_cursor.execute(f"SELECT * FROM {table}")
                rows = sqlite_cursor.fetchall()
                
                if not rows:
                    continue
                
                # 获取列名
                columns = [description[0] for description in sqlite_cursor.description]
                
                # 构建INSERT语句
                placeholders = ', '.join(['%s'] * len(columns))
                columns_str = ', '.join(columns)
                
                # 插入MySQL
                for row in rows:
                    try:
                        mysql_cursor.execute(
                            f"INSERT INTO {table} ({columns_str}) VALUES ({placeholders})",
                            row
                        )
                        migrated_count += 1
                    except Exception as e:
                        print(f"迁移 {table} 数据失败: {e}")
                        continue
            
            mysql_conn.commit()
            sqlite_cursor.close()
            sqlite_conn.close()
            mysql_cursor.close()
            mysql_conn.close()
            
            return True, f"数据迁移成功，共迁移 {migrated_count} 条记录"
            
        except Exception as e:
            return False, f"数据迁移失败: {str(e)}"


# 兼容原有接口
def get_connection():
    """获取数据库连接"""
    return DatabaseManager.get_connection()

def get_db_type():
    """获取当前数据库类型"""
    return DatabaseManager.get_db_type()

def set_db_type(db_type):
    """设置数据库类型"""
    DatabaseManager.set_db_type(db_type)
