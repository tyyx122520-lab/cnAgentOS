# 扩展的数据库模型 - 支持智能聊天、数字员工、多数据库等功能
import os
import sqlite3
import hashlib
import secrets

# 数据库配置
DB_TYPE = os.environ.get('DB_TYPE', 'sqlite')  # sqlite 或 mysql
DB_HOST = os.environ.get('DB_HOST', 'localhost')
DB_PORT = os.environ.get('DB_PORT', '3306')
DB_NAME = os.environ.get('DB_NAME', 'cnagentos')
DB_USER = os.environ.get('DB_USER', 'root')
DB_PASSWORD = os.environ.get('DB_PASSWORD', '')

# 获得项目根路径的方法
def _project_root():
    return os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))

# 获得数据文件的路径
DB_PATH = os.path.join(_project_root(), "database", "app.db")

# 获得数据库连接
def get_connection():
    if DB_TYPE == 'mysql':
        try:
            import pymysql
            conn = pymysql.connect(
                host=DB_HOST,
                port=int(DB_PORT),
                database=DB_NAME,
                user=DB_USER,
                password=DB_PASSWORD,
                charset='utf8mb4',
                cursorclass=pymysql.cursors.DictCursor
            )
            return conn
        except ImportError:
            print("MySQL connector not installed, falling back to SQLite")
    
    # 默认使用 SQLite
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def get_db_type():
    return DB_TYPE

def set_db_type(db_type):
    global DB_TYPE
    DB_TYPE = db_type

# 初始化数据库表
def init_db():
    with get_connection() as conn:
        # 用户表
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS users(
                id integer PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                salt TEXT NOT NULL,
                nickname TEXT,
                avatar TEXT,
                status INTEGER DEFAULT 1,
                create_at TEXT NOT NULL DEFAULT(datetime('now'))
            )
            """
        )
        
        # 角色表
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS roles(
                id integer PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                code TEXT NOT NULL UNIQUE,
                is_system integer DEFAULT 0,
                create_at TEXT NOT NULL DEFAULT(datetime('now'))
            )
            """
        )
        
        # 菜单表
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS menus(
                id integer PRIMARY KEY AUTOINCREMENT,
                parent_id integer DEFAULT 0,
                name TEXT NOT NULL,
                url TEXT,
                icon TEXT,
                order_num integer DEFAULT 0,
                create_at TEXT NOT NULL DEFAULT(datetime('now'))
            )
            """
        )
        
        # 角色菜单映射表
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS role_menus(
                role_id integer,
                menu_id integer,
                PRIMARY KEY (role_id, menu_id)
            )
            """
        )
        
        # 用户角色映射表
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS user_roles(
                user_id integer,
                role_id integer,
                PRIMARY KEY (user_id, role_id)
            )
            """
        )
        
        # 模型引擎表
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS ai_models(
                id integer primary key autoincrement,
                name varchar(100) not null,
                model_name varchar(100) not null,
                api_key varchar(255) not null,
                base_url varchar(255) not null,
                is_default integer default 0,
                total_tokens integer default 0,
                create_at datetime default current_timestamp
            )
            """
        )
        
        # 瞭望数据源管理表
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS spy_sources(
                id integer primary key autoincrement,
                name varchar(100) not null,
                entry_url text not null,
                request_headers text not null,
                is_active integer default 1,
                create_at datetime default current_timestamp
            )
            """
        )
        
        # 数据仓库表
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS spy_data(
                id integer primary key autoincrement,
                source_id integer not null,
                keyword varchar(255) not null,
                title text not null,
                url text not null,
                summary text,
                create_at datetime default current_timestamp,
                update_at datetime
            )
            """
        )
        
        # ===== 智能聊天子系统表 =====
        
        # 好友关系表
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS friendships(
                id integer primary key autoincrement,
                user_id integer not null,
                friend_id integer not null,
                status integer default 1,  -- 0: 待确认, 1: 已确认, 2: 已拉黑
                create_at datetime default current_timestamp,
                UNIQUE(user_id, friend_id)
            )
            """
        )
        
        # 群聊表
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS chat_groups(
                id integer primary key autoincrement,
                name varchar(100) not null,
                avatar TEXT,
                owner_id integer not null,
                description TEXT,
                status integer default 1,  -- 0: 已解散, 1: 正常, 2: 被封禁
                is_system integer default 0,
                announcement TEXT,
                create_at datetime default current_timestamp
            )
            """
        )
        
        # 群成员表
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS group_members(
                id integer primary key autoincrement,
                group_id integer not null,
                user_id integer not null,
                role integer default 0,  -- 0: 成员, 1: 管理员, 2: 群主
                nickname_in_group TEXT,
                join_at datetime default current_timestamp,
                UNIQUE(group_id, user_id)
            )
            """
        )
        
        # 消息表
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS messages(
                id integer primary key autoincrement,
                sender_id integer not null,
                receiver_id integer,  -- 私聊接收者
                group_id integer,     -- 群聊ID
                msg_type integer default 1,  -- 1: 文本, 2: 图片, 3: 文件, 4: emoji, 5: 系统消息
                content TEXT not null,
                file_url TEXT,
                file_name TEXT,
                file_size integer,
                is_read integer default 0,
                is_deleted integer default 0,
                create_at datetime default current_timestamp
            )
            """
        )
        
        # 文件管理表
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS files(
                id integer primary key autoincrement,
                file_hash varchar(64) not null UNIQUE,  -- MD5哈希用于去重
                file_name varchar(255) not null,
                file_path TEXT not null,
                file_size integer not null,
                mime_type varchar(100),
                uploader_id integer,
                ref_count integer default 1,  -- 引用计数
                create_at datetime default current_timestamp
            )
            """
        )
        
        # 数字员工表
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS digital_employees(
                id integer primary key autoincrement,
                name varchar(100) not null UNIQUE,
                display_name varchar(100) not null,
                avatar TEXT,
                description TEXT,
                employee_type varchar(50) not null,  -- chuan_nong, weather, toxic_soup, custom
                prompt_template TEXT,  -- 系统提示词
                model_id integer,      -- 关联的AI模型
                tools TEXT,            -- JSON格式存储的工具列表
                is_active integer default 1,
                create_at datetime default current_timestamp
            )
            """
        )
        
        # 聊天服务器表
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS chat_servers(
                id integer primary key autoincrement,
                name varchar(100) not null,
                host varchar(255) not null,
                port integer not null,
                ws_port integer,
                status integer default 1,  -- 0: 离线, 1: 在线, 2: 维护中
                priority integer default 0,
                is_default integer default 0,
                create_at datetime default current_timestamp
            )
            """
        )
        
        # 工具管理表
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS tools(
                id integer primary key autoincrement,
                name varchar(100) not null UNIQUE,
                display_name varchar(100) not null,
                description TEXT,
                tool_type varchar(50) not null,  -- api, function, plugin
                config TEXT,  -- JSON配置
                is_active integer default 1,
                create_at datetime default current_timestamp
            )
            """
        )
        
        # 数字员工工具绑定表
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS employee_tools(
                employee_id integer,
                tool_id integer,
                config TEXT,  -- 工具特定配置
                PRIMARY KEY (employee_id, tool_id)
            )
            """
        )
        
        # 舆情数据表
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS sentiment_data(
                id integer primary key autoincrement,
                source_type varchar(50) not null,  -- chat, spy
                source_id integer not null,
                content TEXT not null,
                sentiment_score real,  -- 情感分数 -1到1
                keywords TEXT,  -- JSON格式关键词
                analysis_result TEXT,
                create_at datetime default current_timestamp
            )
            """
        )
        
        # 创建索引
        conn.execute("CREATE INDEX IF NOT EXISTS idx_friendships_user ON friendships(user_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_friendships_friend ON friendships(friend_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_group_members_group ON group_members(group_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_group_members_user ON group_members(user_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_messages_sender ON messages(sender_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_messages_receiver ON messages(receiver_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_messages_group ON messages(group_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_messages_create_at ON messages(create_at)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_spy_data_source_url ON spy_data(source_id, url)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_sentiment_source ON sentiment_data(source_type, source_id)")
        
        # 历史版本兼容
        try:
            conn.execute("ALTER TABLE spy_data ADD COLUMN update_at datetime")
        except sqlite3.OperationalError:
            pass
        
        try:
            conn.execute("ALTER TABLE users ADD COLUMN nickname TEXT")
            conn.execute("ALTER TABLE users ADD COLUMN avatar TEXT")
            conn.execute("ALTER TABLE users ADD COLUMN status INTEGER DEFAULT 1")
        except sqlite3.OperationalError:
            pass
        
        conn.commit()

# 初始化默认数字员工
def init_default_employees():
    from app.models.db import get_connection
    with get_connection() as conn:
        # 检查是否已有数字员工
        cursor = conn.execute("SELECT COUNT(*) as count FROM digital_employees")
        if cursor.fetchone()['count'] > 0:
            return
        
        # 川农小助手
        chuan_nong_prompt = """你是川农小助手，专门回答关于四川农业大学（Sichuan Agricultural University，简称川农、SICAU）的问题。

你的知识范围包括：
1. 川农的历史沿革、校区分布（雅安、成都、都江堰）
2. 学校的院系设置、专业介绍
3. 学校的知名校友、科研成果
4. 校园生活、食堂、宿舍、图书馆等
5. 学校的招生政策、录取分数线
6. 学校的校训、校徽、校园文化

你只能回答与川农相关的问题。如果用户询问与川农无关的内容，请礼貌地告知用户你只能回答川农相关问题，并询问是否有其他关于川农的问题可以帮助。

回答风格：友好、专业、简洁明了。"""
        
        conn.execute(
            """INSERT INTO digital_employees 
            (name, display_name, avatar, description, employee_type, prompt_template, is_active)
            VALUES (?, ?, ?, ?, ?, ?, ?)""",
            ("chuan_nong_assistant", "川农小助手", 
             "/static/images/avatars/chuan_nong.png",
             "专门回答四川农业大学相关问题的智能助手",
             "chuan_nong", chuan_nong_prompt, 1)
        )
        
        # 天气小助手
        weather_prompt = """你是天气小助手，专门提供天气信息查询服务。

当用户询问天气时：
1. 识别用户提到的城市名称
2. 提供该城市的当前天气信息
3. 可以给出穿衣建议、出行建议等

如果用户没有指定城市，请询问用户想查询哪个城市的天气。

回答风格：简洁实用，可以附带温馨的提醒。"""
        
        conn.execute(
            """INSERT INTO digital_employees 
            (name, display_name, avatar, description, employee_type, prompt_template, is_active)
            VALUES (?, ?, ?, ?, ?, ?, ?)""",
            ("weather_assistant", "天气小助手",
             "/static/images/avatars/weather.png",
             "提供实时天气查询和天气建议的智能助手",
             "weather", weather_prompt, 1)
        )
        
        # 毒鸡汤助手
        toxic_prompt = """你是毒鸡汤助手，专门提供幽默、扎心但又有道理的"毒鸡汤"语录。

当用户与你对话时，随机返回一条毒鸡汤语录。语录应该：
1. 幽默风趣，带有一点讽刺意味
2. 反映现实，让人会心一笑
3. 不恶意攻击，只是轻松的自嘲或调侃
4. 适合年轻人，关于工作、生活、学习、爱情等话题

示例语录：
- "努力不一定成功，但不努力一定很轻松。"
- "失败并不可怕，可怕的是你还相信这句话。"
- "有时候你不努力一下，你都不知道什么叫绝望。"

每次回复一条不同的语录。"""
        
        conn.execute(
            """INSERT INTO digital_employees 
            (name, display_name, avatar, description, employee_type, prompt_template, is_active)
            VALUES (?, ?, ?, ?, ?, ?, ?)""",
            ("toxic_soup_assistant", "毒鸡汤助手",
             "/static/images/avatars/toxic.png",
             "提供幽默扎心毒鸡汤语录的智能助手",
             "toxic_soup", toxic_prompt, 1)
        )
        
        conn.commit()

# 初始化默认聊天服务器
def init_default_servers():
    from app.models.db import get_connection
    with get_connection() as conn:
        cursor = conn.execute("SELECT COUNT(*) as count FROM chat_servers")
        if cursor.fetchone()['count'] > 0:
            return
        
        conn.execute(
            """INSERT INTO chat_servers 
            (name, host, port, ws_port, status, priority, is_default)
            VALUES (?, ?, ?, ?, ?, ?, ?)""",
            ("主服务器", "localhost", 10086, 10087, 1, 1, 1)
        )
        conn.commit()
