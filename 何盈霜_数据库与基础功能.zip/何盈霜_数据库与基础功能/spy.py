import tornado.web
import json
import urllib.parse
import asyncio
import re
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from bs4 import BeautifulSoup
from app.controllers.base import BaseHandler
from app.models.spy_source import SpySourceRepository
from app.models.data_warehouse import DataWarehouseRepository

class SpyPageHandler(BaseHandler):
    # 独立风格采集页面，不继承后台框架
    @tornado.web.authenticated
    def get(self):
        self.render("spy/spy.html")

class SpyRunApiHandler(BaseHandler):
    @tornado.web.authenticated
    async def get(self):
        source_id = int(self.get_argument("source_id", 0))
        keyword = self.get_argument("keyword", "")
        max_pages = int(self.get_argument("max_pages", 1))
        page_step = int(self.get_argument("page_step", 10))

        # 设置 SSE 响应头
        self.set_header('Content-Type', 'text/event-stream')
        self.set_header('Cache-Control', 'no-cache')
        self.set_header('Connection', 'keep-alive')

        source_info = SpySourceRepository.get_source_by_id(source_id)
        if not source_info or not keyword:
            self.write(f"data: {json.dumps({'type':'error', 'msg':'参数错误或未找到数据源'})}\n\n")
            await self.flush()
            return

        headers_dict = {}
        try:
            # 简单解析换行格式的 headers
            for line in source_info['request_headers'].split('\n'):
                if ':' in line and not line.startswith(('GET', 'POST', 'Host')):
                    k, v = line.split(':', 1)
                    key = k.strip()
                    if key.lower() == "cookie":
                        continue
                    if key.lower() == "accept-encoding":
                        continue
                    headers_dict[key] = v.strip()
        except Exception:
            pass
        
        def ensure_header(headers: dict, key: str, value: str):
            for k in headers.keys():
                if k.lower() == key.lower():
                    return
            headers[key] = value

        ensure_header(headers_dict, "User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36")
        ensure_header(headers_dict, "Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
        ensure_header(headers_dict, "Accept-Language", "zh-CN,zh;q=0.9")

        import tornado.ioloop
        total_items = 0
        seen_key = set()

        for page in range(max_pages):
            pn = page * page_step
            # 动态替换参数
            target_url = source_info['entry_url']
            target_url = target_url.replace('{关键字}', urllib.parse.quote(keyword))
            target_url = re.sub(r'\{分页步进[^}]*\}', str(pn), target_url)
            if "pn=" not in target_url:
                joiner = "&" if "?" in target_url else "?"
                target_url = f"{target_url}{joiner}pn={pn}"
            
            self.write(f"data: {json.dumps({'type':'log', 'level':'info', 'msg':f'正在请求第 {page+1} 页数据... pn={pn}'})}\n\n")
            await self.flush()

            def fetch_data():
                try:
                    session = requests.Session()
                    retry = Retry(
                        total=2,
                        connect=2,
                        read=2,
                        status=2,
                        backoff_factor=0.6,
                        status_forcelist=(429, 500, 502, 503, 504),
                        allowed_methods=frozenset(["GET"])
                    )
                    adapter = HTTPAdapter(max_retries=retry, pool_connections=10, pool_maxsize=10)
                    session.mount("https://", adapter)
                    session.mount("http://", adapter)
                    res = session.get(target_url, headers=headers_dict, timeout=(8, 25))
                    res.encoding = res.apparent_encoding or "utf-8"
                    text = res.text or ""
                    return {"ok": res.status_code == 200, "status": res.status_code, "text": text}
                except requests.exceptions.ConnectTimeout as e:
                    return {"ok": False, "status": None, "text": "", "error": f"连接超时：{str(e)}"}
                except requests.exceptions.ReadTimeout as e:
                    return {"ok": False, "status": None, "text": "", "error": f"读取超时：{str(e)}"}
                except requests.exceptions.SSLError as e:
                    return {"ok": False, "status": None, "text": "", "error": f"SSL 错误：{str(e)}"}
                except requests.exceptions.ConnectionError as e:
                    return {"ok": False, "status": None, "text": "", "error": f"连接失败：{str(e)}"}
                except Exception as e:
                    return {"ok": False, "status": None, "text": "", "error": str(e)}

            fetch_result = await tornado.ioloop.IOLoop.current().run_in_executor(None, fetch_data)
            html_content = fetch_result.get("text", "")
            
            if not fetch_result.get("ok") or not html_content:
                status = fetch_result.get("status")
                err = fetch_result.get("error", "")
                msg = f"第 {page+1} 页请求失败 status={status} err={err}"
                self.write(f"data: {json.dumps({'type':'log', 'level':'error', 'msg': msg})}\n\n")
                await self.flush()
                continue

            if ("百度安全验证" in html_content) or ("请输入验证码" in html_content) or ("安全验证" in html_content and "baidu.com" in html_content):
                self.write(f"data: {json.dumps({'type':'error', 'msg':'触发百度安全验证/验证码拦截，建议稍后重试或更换网络环境/降低频率'})}\n\n")
                await self.flush()
                return

            # 使用 bs4 简单解析百度新闻结构的通用逻辑
            def parse_items():
                soup = BeautifulSoup(html_content, 'html.parser')

                # 多策略提取：优先抓取 h3 a（百度资讯搜索通常如此），其次兼容 c-container/result-op
                link_nodes = soup.select('h3 a')
                if not link_nodes:
                    link_nodes = soup.select('div.result-op h3 a, div.c-container h3 a, div.result h3 a')

                # 去重（按 href）
                seen = set()
                links = []
                for a in link_nodes:
                    href = a.get('href') or ""
                    title = a.get_text(" ", strip=True)
                    if not href or not title:
                        continue
                    if href in seen:
                        continue
                    seen.add(href)
                    links.append(a)

                items = []
                for a in links:
                    title = a.get_text(" ", strip=True)
                    url = a.get('href') or ""
                    if not url or not title:
                        continue

                    container = a.find_parent('div', class_=re.compile(r'(result|c-container|result-op)', re.I)) or a.find_parent('div')
                    summary = ""
                    if container:
                        summary_node = (
                            container.select_one('span.c-font-normal')
                            or container.select_one('div.c-summary')
                            or container.select_one('div.c-abstract')
                            or container.select_one('div.content')
                        )
                        if summary_node:
                            summary = summary_node.get_text(" ", strip=True)
                        else:
                            text_all = container.get_text(" ", strip=True)
                            if text_all:
                                summary = text_all.replace(title, "").strip()
                    if len(summary) > 500:
                        summary = summary[:500]

                    items.append({
                        "source_id": source_id,
                        "keyword": keyword,
                        "title": title,
                        "url": url,
                        "summary": summary
                    })
                return items, len(links)

            items, extracted = await tornado.ioloop.IOLoop.current().run_in_executor(None, parse_items)
            pushed = 0
            for it in items:
                key = (it.get("source_id"), it.get("url"))
                if key in seen_key:
                    continue
                seen_key.add(key)
                self.write(f"data: {json.dumps({'type':'item', 'data': it}, ensure_ascii=False)}\n\n")
                pushed += 1

            total_items += pushed
            self.write(f"data: {json.dumps({'type':'log', 'level':'info', 'msg':f'第 {page+1} 页解析诊断：HTML长度={len(html_content)} | 提取链接={extracted} | 新增候选={pushed}'})}\n\n")
            self.write(f"data: {json.dumps({'type':'log', 'level':'success', 'msg':f'第 {page+1} 页解析完成，累计候选 {total_items} 条。'})}\n\n")
            await self.flush()
            
            # 随机休眠防封
            await asyncio.sleep(1.5)

        self.write(f"data: {json.dumps({'type':'done', 'count':total_items})}\n\n")
        await self.flush()


class SpyCommitApiHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        try:
            items_json = self.get_argument("items", "[]")
            items = json.loads(items_json) if items_json else []
            if not isinstance(items, list):
                return self.write({"code": 1, "msg": "参数 items 格式错误"})
            result = DataWarehouseRepository.upsert_batch(items)
            self.write({"code": 0, "msg": "入库成功", "data": result})
        except Exception as e:
            self.write({"code": 1, "msg": f"入库失败: {str(e)}"})
