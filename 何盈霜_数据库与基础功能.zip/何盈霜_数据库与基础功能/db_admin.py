# 数据库管理控制器
import tornado.web
import json
import os
from app.controllers.base import BaseHandler
from app.models.db_manager import DatabaseManager

class DatabaseAdminHandler(BaseHandler):
    """数据库管理页面"""
    @tornado.web.authenticated
    def get(self):
        self.render("db_admin/index.html", title="数据库管理")

class DatabaseAdminApiHandler(BaseHandler):
    """数据库管理API"""
    @tornado.web.authenticated
    def get(self):
        """获取数据库状态"""
        action = self.get_argument("action", "status")
        
        if action == "status":
            # 获取当前数据库状态
            db_type = DatabaseManager.get_db_type()
            
            status = {
                "current_type": db_type,
                "sqlite_path": os.path.join(os.path.dirname(__file__), '..', '..', 'database', 'app.db'),
                "mysql_config": {
                    "host": os.environ.get('DB_HOST', 'localhost'),
                    "port": os.environ.get('DB_PORT', '3306'),
                    "database": os.environ.get('DB_NAME', 'cnagentos'),
                    "user": os.environ.get('DB_USER', 'root'),
                } if db_type == 'mysql' else None
            }
            
            self.write({"code": 0, "data": status})
            
        elif action == "test_mysql":
            # 测试MySQL连接
            host = self.get_argument("host", "")
            port = int(self.get_argument("port", 3306))
            database = self.get_argument("database", "")
            user = self.get_argument("user", "")
            password = self.get_argument("password", "")
            
            success, msg = DatabaseManager.test_mysql_connection(host, port, database, user, password)
            self.write({"code": 0 if success else 1, "msg": msg})
    
    @tornado.web.authenticated
    def post(self):
        """数据库管理操作"""
        action = self.get_argument("action", "")
        
        if action == "switch_to_mysql":
            # 切换到MySQL
            host = self.get_argument("host", "").strip()
            port = int(self.get_argument("port", 3306))
            database = self.get_argument("database", "").strip()
            user = self.get_argument("user", "").strip()
            password = self.get_argument("password", "").strip()
            migrate = self.get_argument("migrate", "false") == "true"
            
            if not all([host, database, user]):
                self.write({"code": 1, "msg": "主机、数据库名和用户名不能为空"})
                return
            
            # 测试连接
            success, msg = DatabaseManager.test_mysql_connection(host, port, database, user, password)
            if not success:
                self.write({"code": 1, "msg": f"MySQL连接测试失败: {msg}"})
                return
            
            # 更新环境变量
            os.environ['DB_TYPE'] = 'mysql'
            os.environ['DB_HOST'] = host
            os.environ['DB_PORT'] = str(port)
            os.environ['DB_NAME'] = database
            os.environ['DB_USER'] = user
            os.environ['DB_PASSWORD'] = password
            
            # 初始化MySQL表
            success, msg = DatabaseManager.init_mysql_tables()
            if not success:
                self.write({"code": 1, "msg": msg})
                return
            
            # 如果需要迁移数据
            if migrate:
                success, msg = DatabaseManager.migrate_sqlite_to_mysql()
                if not success:
                    self.write({"code": 1, "msg": f"数据迁移失败: {msg}"})
                    return
            
            # 切换数据库类型
            DatabaseManager.set_db_type('mysql')
            
            self.write({"code": 0, "msg": "已成功切换到MySQL数据库" + ("，数据已迁移" if migrate else "")})
            
        elif action == "switch_to_sqlite":
            # 切换到SQLite
            os.environ['DB_TYPE'] = 'sqlite'
            DatabaseManager.set_db_type('sqlite')
            
            self.write({"code": 0, "msg": "已成功切换到SQLite数据库"})
            
        elif action == "init_mysql":
            # 仅初始化MySQL表
            success, msg = DatabaseManager.init_mysql_tables()
            self.write({"code": 0 if success else 1, "msg": msg})
            
        elif action == "migrate":
            # 迁移数据
            success, msg = DatabaseManager.migrate_sqlite_to_mysql()
            self.write({"code": 0 if success else 1, "msg": msg})
            
        else:
            self.write({"code": 1, "msg": "未知操作"})
